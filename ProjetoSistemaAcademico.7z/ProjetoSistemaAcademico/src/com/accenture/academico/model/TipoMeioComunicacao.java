package com.accenture.academico.model;

public enum TipoMeioComunicacao {

	
	Celular("Celular"),Tablet("Tablet"), Browser("Browser(Navegador)");
	
	private final String valor;
	TipoMeioComunicacao(String valorOpcao){
		valor = valorOpcao;
	}
	public String getValor(){
		return valor;
	}
}

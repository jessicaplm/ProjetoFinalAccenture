package com.accenture.academico.model;

public enum TipoPessoa {
	
	Aluno("Aluno"),Professor("Professor");

	private final String valor;
	TipoPessoa(String valorOpcao){
		valor = valorOpcao;
	}
	public String getValor(){
		return valor;
	}
}
